function myFunction() {
    var x = document.getElementById("myDIV");
    var y = document.getElementById("myDIV2");
    var z = document.getElementById("myDIV3");
    var xx = document.getElementById("rentid");
    var yy = document.getElementById("leaseid");
    var zz = document.getElementById("dpid");
    xx.style.display = "block";
    $("#leaseid").fadeIn();
    $("#dpid").fadeIn();
    if (zz.style.display === "block") {
        zz.style.display = "none";
    }
    if (yy.style.display === "block") {
        yy.style.display = "none";
    }
    if (x.style.display === "none") {
        z.style.display = "none";
        y.style.display = "none";
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function myFunction2() {
    var z = document.getElementById("myDIV3");
    var x = document.getElementById("myDIV2");
    var y = document.getElementById("myDIV");
    var xx = document.getElementById("rentid");
    var yy = document.getElementById("leaseid");
    var zz = document.getElementById("dpid");

    $("#rentid").slideUp();
    $("#dpid").slideUp();
    if (xx.style.display === "block") {
        xx.style.display = "none";
    }
    yy.style.display = "block";
    if (zz.style.display === "block") {
        zz.style.display = "none";
    }

    if (x.style.display === "none") {
        z.style.display = "none";
        y.style.display = "none";
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function myFunction3() {
    var z = document.getElementById("myDIV3");
    var x = document.getElementById("myDIV2");
    var y = document.getElementById("myDIV");
    var xx = document.getElementById("rentid");
    var yy = document.getElementById("leaseid");
    var zz = document.getElementById("dpid");
    $("#rentid").slideUp();
    $("#leaseid").slideUp();
    if (xx.style.display === "block") {
        xx.style.display = "none";
    }
    if (yy.style.display === "block") {
        yy.style.display = "none";
    }
    zz.style.display = "block";
    if (z.style.display === "none") {
        y.style.display = "none";
        x.style.display = "none";
        z.style.display = "block";
    } else {
        z.style.display = "none";
    }
}

$(document).ready(function() {
    var x = document.getElementById("myDIV");
    var y = document.getElementById("myDIV2");
    var z = document.getElementById("myDIV3");
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "none";
    $(".cartype1").hover(function() {
        $("#rentid").slideDown();
        $("#leaseid").slideUp();
        $("#dpid").slideUp();
        document.getElementById("myDIV2").style.display = "none";
        document.getElementById("myDIV3").style.display = "none";

    });
    $(".cartype2").hover(function() {
        $("#rentid").slideUp();
        $("#dpid").slideUp();
        $("#leaseid").slideDown();
        document.getElementById("myDIV").style.display = "none";
        document.getElementById("myDIV3").style.display = "none";
    });
    $(".cartype3").hover(function() {
        $("#rentid").slideUp();
        $("#leaseid").slideUp();
        $("#dpid").slideDown();
        document.getElementById("myDIV2").style.display = "none";
        document.getElementById("myDIV").style.display = "none";
    });
});